import numpy as np
import pytest

from scripts.validate_task11_complete_pipeline import (
    family_ancestry,
    gamete,
    partition_metrics,
    relationship_metrics,
)


def test_joint_family_founder_haplotypes_are_disjoint_and_inheritance_is_valid():
    rng = np.random.default_rng(19011)
    cm = np.linspace(0, 100, 1001)
    previous_ids = set()
    offset = 0
    for mating in ("unrelated", "first_cousins", "siblings"):
        family, next_offset = family_ancestry(mating, cm, rng, offset)
        assert family.shape == (4, 2, 1001)
        assert family.min() >= offset
        assert family.max() < next_offset
        assert not (set(family.ravel()) & previous_ids)
        previous_ids.update(family.ravel())
        if mating == "unrelated":
            assert not np.any(family[:, 0] == family[:, 1])
        offset = next_offset


def test_gamete_preserves_parental_ancestry_at_each_marker():
    parent = np.array([[10, 11, 12], [20, 21, 22]])
    for seed in range(12):
        result = gamete(
            parent, np.array([0.0, 50.0, 100.0]), np.random.default_rng(seed)
        )
        assert np.all((result == parent[0]) | (result == parent[1]))


def test_partition_counts_missing_and_merged_pairs_instead_of_dropping_them():
    result = partition_metrics([["a", "b"], ["c", "d"]], [["a", "c"], ["b"]])
    assert result["missing_samples"] == ["d"]
    assert result["missed_within_pairs"] == 2
    assert result["false_cross_family_pairs"] == 1
    assert result["exactly_recovered_families"] == 0
    assert result["split_families"] == 1
    assert result["merged_predicted_families"] == 1


def test_partition_rejects_duplicate_or_unknown_samples():
    with pytest.raises(ValueError, match="Duplicate"):
        partition_metrics([["a", "b"]], [["a"], ["a", "b"]])
    with pytest.raises(ValueError, match="Unknown"):
        partition_metrics([["a", "b"]], [["a", "x"]])


def test_relationship_denominator_includes_missing_true_pairs_and_cross_family_errors():
    truth = {
        "families": [["a", "b"], ["c", "d"]],
        "samples": ["a", "b", "c", "d"],
        "family_mating_types": ["unrelated", "siblings"],
        "relationship": "siblings",
    }
    result = relationship_metrics(
        truth,
        [
            {"indID1": "b", "indID2": "a", "relation": "siblings"},
            {"indID1": "a", "indID2": "c", "relation": "siblings"},
        ],
    )
    assert result["truth_pairs"] == 2
    assert result["accuracy_counting_missing_as_wrong"] == 0.5
    assert result["missing_true_pairs"] == 1
    assert result["extra_cross_family_predictions"] == 1
    assert (
        result["by_parent_mating_type"]["siblings"][
            "accuracy_counting_missing_as_wrong"
        ]
        == 0
    )


def test_relationship_rejects_duplicate_predictions():
    truth = {
        "families": [["a", "b"]],
        "samples": ["a", "b"],
        "family_mating_types": ["unrelated"],
        "relationship": "siblings",
    }
    row = {"indID1": "a", "indID2": "b", "relation": "siblings"}
    with pytest.raises(ValueError, match="Duplicate prediction"):
        relationship_metrics(truth, [row, row])
