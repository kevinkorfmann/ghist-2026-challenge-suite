"""Freeze outputs must describe their retained fits and valid physical intervals."""
from __future__ import annotations

import json
import sys

import pytest

from ghist_growth_bgs.simulation import SIMULATION_SCALING_SCHEME
from scripts import freeze_growth_bgs as growth
from scripts import freeze_split_migration_bgs as split


def sources_for(task, tmp_path):
    from test_demography_bootstrap_contract import bootstrap_fixture
    from ghist_inference.bootstrap import summarize_payloads
    verified_bootstrap = summarize_payloads([bootstrap_fixture(tmp_path, task)], task)
    scaling = {'simulation_scaling_scheme': SIMULATION_SCALING_SCHEME}
    if task == 3:
        fit = {'generations': 1000., 'post_growth_scaling': 2., 'best_restart_converged': True,
               'mutation_rate': 3.36e-8, 'convention': 'exponential'}
        sources = {
            'audit': {'files': {name: {'sha256': '0' * 64} for name in ['vcf', 'coding_bed', 'recombination_map']},
                      'segregating_biallelic_sites': 1, 'expected_haplotypes': 84,
                      'physical_bp_by_distance_stratum': {'noncoding_1kb_10kb': 1, 'noncoding_10kb_100kb': 1}},
            'middle-fit': {'strata': {'noncoding_1kb_100kb': {
                'by_projection': {str(p): dict(fit, projection=p) for p in [84, 60, 40]}, 'median': dict(fit)}}},
            'bootstrap': {'replicates': 2, 'generations': {'quantiles': {'0.025': 500., '0.975': 1500.}},
                          'post_growth_scaling': {'quantiles': {'0.025': 1.5, '0.975': 2.5}}},
            'convention': {}, 'model-comparison': {'selected_convention': 'exponential', 'selection_consistent_across_groups': True},
            'smoke': {**scaling, 'preferred': 'exponential'},
            'grid': {**scaling, 'results': {'synthetic': {'relative_error': {'generations': 0., 'post_growth_scaling': 0.}}}},
            'calibration': {**scaling, 'selected_model': 'identity', 'validation': {}, 'evaluations': {}},
            'stress': {**scaling, 'freeze_gate_passed': True},
        }
        sources['bootstrap'] = verified_bootstrap
        return growth, sources, ['final-sealed-sha256']
    fit = {'AFR_population_size': 12000., 'EUR_population_size': 9000.,
           'generations_since_split': 1000., 'migration_rate': 1e-4,
           'best_restart_converged': True, 'projection': [50, 40], 'mutation_rate': 1.015e-8}
    sources = {
        'baseline': {'by_projection': {p: dict(fit, projection=[int(value) for value in p.split('x')]) for p in ['50x40', '70x50', '94x68']},
                     'projection_median': dict(fit),
                     'metadata': {'ancestral_reference_records': 1, 'haplotypes': [94, 68]}, 'physical_exposure_bp': 2},
        'refined': dict(fit),
        'bootstrap': {'replicates': 2, 'parameters': {
            name: {'quantiles': {'0.025': fit[name] * .5, '0.975': fit[name] * 1.5}}
            for name in split.PARAMETERS}},
        'calibration': {**scaling, 'selected_model': 'identity', 'validation': {}, 'truth_points': [], 'evaluations': {}},
        'near-recovery': {**scaling, 'relative_error': {name: 0. for name in split.PARAMETERS}},
    }
    sources['bootstrap'] = verified_bootstrap
    return split, sources, ['testing-vcf-sha256', 'coding-bed-sha256', 'recombination-map-sha256', 'final-sealed-sha256']


def fields(task, sources):
    if task == 3:
        block = sources['middle-fit']['strata']['noncoding_1kb_100kb']
        return block['by_projection'], block['median'], sources['bootstrap'], 'generations'
    block = sources['baseline']
    return block['by_projection'], block['projection_median'], sources['bootstrap']['parameters'], 'generations_since_split'


def freeze(module, sources, flags, tmp_path, monkeypatch):
    output = tmp_path / 'freeze.json'
    argv = ['freeze', '--out', str(output)]
    for flag in flags:
        argv.extend(['--' + flag, '0' * 64])
    for flag, payload in sources.items():
        path = tmp_path / (flag + '.json')
        path.write_text(json.dumps(payload))
        argv.extend(['--' + flag, str(path)])
    monkeypatch.setattr(sys, 'argv', argv)
    module.main()
    return json.loads(output.read_text())


@pytest.mark.parametrize('task', [3, 4])
def test_freeze_recomputes_median_and_preserves_valid_quantile_schema(task, tmp_path, monkeypatch):
    module, sources, flags = sources_for(task, tmp_path)
    fits, stored, _, parameter = fields(task, sources)
    projections = list(fits)
    fits[projections[1]][parameter] = 800.
    fits[projections[2]][parameter] = 1200.
    # Only serialization-level rounding is tolerated; export the computed median.
    stored[parameter] = 1000. + 1e-10
    output = freeze(module, sources, flags, tmp_path, monkeypatch)
    assert output['testing_prediction'][parameter] == 1000.
    assert len(output['validation']['projection_fits']) == 3


@pytest.mark.parametrize('task', [3, 4])
def test_inconsistent_cached_median_cannot_pass_converged_projection_gate(task, tmp_path, monkeypatch):
    module, sources, flags = sources_for(task, tmp_path)
    _, stored, _, parameter = fields(task, sources)
    stored[parameter] = 2000.
    with pytest.raises(ValueError, match='stored median differs'):
        freeze(module, sources, flags, tmp_path, monkeypatch)
    assert not (tmp_path / 'freeze.json').exists()


@pytest.mark.parametrize('task', [3, 4])
@pytest.mark.parametrize('bad', [float('nan'), float('inf'), -1., 0., True, None, 'invalid', 2000.])
def test_invalid_interval_cannot_create_freeze_output(task, bad, tmp_path, monkeypatch):
    module, sources, flags = sources_for(task, tmp_path)
    _, _, intervals, parameter = fields(task, sources)
    intervals[parameter]['quantiles']['0.025'] = bad
    with pytest.raises(ValueError, match='interval|quantiles'):
        freeze(module, sources, flags, tmp_path, monkeypatch)
    assert not (tmp_path / 'freeze.json').exists()
    assert not list(tmp_path.glob('.freeze.json.*'))


@pytest.mark.parametrize('task', [3, 4])
@pytest.mark.parametrize('omission', ['parameter', 'quantile', 'malformed_quantiles'])
def test_required_interval_fields_fail_explicitly(task, omission, tmp_path, monkeypatch):
    module, sources, flags = sources_for(task, tmp_path)
    _, _, intervals, parameter = fields(task, sources)
    if omission == 'parameter':
        del intervals[parameter]
    elif omission == 'quantile':
        del intervals[parameter]['quantiles']['0.975']
    else:
        intervals[parameter]['quantiles'] = []
    with pytest.raises(ValueError, match='quantiles'):
        freeze(module, sources, flags, tmp_path, monkeypatch)
    assert not (tmp_path / 'freeze.json').exists()


def test_growth_interval_must_respect_existing_growth_ratio_domain(tmp_path, monkeypatch):
    module, sources, flags = sources_for(3, tmp_path)
    sources['bootstrap']['post_growth_scaling']['quantiles']['0.025'] = 1.
    with pytest.raises(ValueError, match='physical domain|quantiles'):
        freeze(module, sources, flags, tmp_path, monkeypatch)
    assert not (tmp_path / 'freeze.json').exists()


def test_zero_migration_interval_boundary_is_valid_without_widening_fit_policy():
    from ghist_inference.freeze import validated_intervals
    assert validated_intervals({'migration_rate': [0., .01]}, ('migration_rate',),
                               nonnegative=('migration_rate',)) == {'migration_rate': [0., .01]}


@pytest.mark.parametrize('task', [3, 4])
def test_nonfinite_embedded_evidence_does_not_replace_existing_artifact(task, tmp_path, monkeypatch):
    module, sources, flags = sources_for(task, tmp_path)
    sources['calibration']['evaluations']['invalid'] = float('nan')
    target = tmp_path / 'freeze.json'
    target.write_text('preserved old artifact')
    with pytest.raises(ValueError, match='JSON compliant'):
        freeze(module, sources, flags, tmp_path, monkeypatch)
    assert target.read_text() == 'preserved old artifact'


def test_every_growth_projection_must_respect_model_domain(tmp_path, monkeypatch):
    module, sources, flags = sources_for(3, tmp_path)
    fits, _, _, _ = fields(3, sources)
    fits['40']['post_growth_scaling'] = 0.9
    with pytest.raises(ValueError, match='scaling greater than one'):
        freeze(module, sources, flags, tmp_path, monkeypatch)
    assert not (tmp_path / 'freeze.json').exists()
