"""Relatedness inference utilities."""
