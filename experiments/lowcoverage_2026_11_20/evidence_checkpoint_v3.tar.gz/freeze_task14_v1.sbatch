#!/bin/bash
#SBATCH --job-name=ghist-lowcov-freeze
#SBATCH --partition=genoa-std-mem
#SBATCH --cpus-per-task=4
#SBATCH --mem-per-cpu=5632M
#SBATCH --time=00:15:00
#SBATCH --output=/vast/projects/smathi/cohort/korfmann/ghist2026/experiments/lowcoverage-20261120/freeze-task14-%j.log
source /etc/profile
set -euo pipefail
TASK_ROOT=/vast/projects/smathi/cohort/korfmann/ghist2026/experiments/lowcoverage-20261120
/vast/projects/smathi/cohort/korfmann/ghist2026/.venv/bin/python "$TASK_ROOT/lowcoverage_confirm_guard_v1.py" --root "$TASK_ROOT" --freeze
