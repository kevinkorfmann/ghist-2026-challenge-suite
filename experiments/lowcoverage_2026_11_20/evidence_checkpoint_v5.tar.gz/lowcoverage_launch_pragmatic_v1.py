import ast
from datetime import datetime, timezone
import hashlib
import importlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

r=Path('/vast/projects/smathi/cohort/korfmann/ghist2026/experiments/lowcoverage-20261120')
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,d):
 p=r/name
 with p.open('x') as f: f.write(json.dumps(d,indent=2,sort_keys=True,allow_nan=False)+'\n')
 return h(p)
assert not list(r.glob('window_extended_development*'))
assert not list(r.glob('full_extended_confirmation*'))
assert not list(r.glob('full_stabilized_confirmation*'))
assert not list(r.glob('window_pragmatic_development*'))
closed_sha=put('task14_extension_strict_path_closed_v1.json',{
 'registered_at_utc':datetime.now(timezone.utc).isoformat(),
 'strict_path_status':'CLOSED, no cap500 scientific results and no fresh confirmation data generated.',
 'v1_failure':'Scheduler completed-job query returned nonzero before dispatch; deadline subsequently passed.',
 'v2_job':'10858043; both workers failed actual start guard before input access at 20:20:25 UTC.',
 'v3_failure':'Dispatch guard failed before sbatch at 2026-11-20T20:23:10.509906+00:00 > 20:23:00.',
 'v3_freeze_sha256':h(r/'task14_extension_freeze_v3.json'),
 'fresh_963xxx_seeds_consumed':False,'strict_cap500_outputs_exist':False,
 'earlier_failed_policies_preserved':True})
authorization_sha=put('task14_pragmatic_authorization_v1.json',{
 'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
 'authorizing_agent':'/root',
 'basis':'User explicitly requested more submissions if somewhat OK; parent explicitly authorized a separate pragmatic development path after strict path closed.',
 'scope':'same frozen cap500 scientific engine, both old Q30/Q20 development SAF cases; no fresh generation; root owns any final input or submission.',
 'resources':{'development_concurrent_jobs':2,'cpus_per_job':4,'minutes_per_job':55,'development_cpu_hour_cap':22/3},
 'actual_development_latest_start_utc':'2026-11-20T20:45:00Z',
 'root_final_latest_start_utc':'2026-11-20T22:00:00Z',
 'scientific_gate_changes':False,'strict_qualification_required_for_pragmatic_review':False})
plan={
 'registered_at_utc':datetime.now(timezone.utc).isoformat(),
 'policy':'task14_separate_pragmatic_cap500_v1',
 'objective':'Provide a fixed, reviewable Task14 candidate and honest measured limitations for root pragmatic submission judgment.',
 'authorization_sha256':authorization_sha,'closed_strict_path_sha256':closed_sha,
 'old_strict_protocol_sha256':h(r/'task14_extension_protocol_v3.json'),
 'engine':'ANGSD GL2 full-width SAF; winsfs0.7.0 full window 500/500; globally folded joint spectrum; frozen moments two-population split without migration.',
 'engine_source_namespace':'source_v12; all 25 source_v11 files copied byte-for-byte, only separate wrappers added.',
 'method':{'blocks':500,'window_size':500,'tolerance':1e-6,'max_epochs':500,'seeds':[761001,761002],'continued_seed':761001,'continued_initial':'seed1 unfolded spectrum','primary_estimate':'seed1','threads':4},
 'development_cases':['full_confirmation_split_r0_p0_v1','full_confirmation_split_r0_p1_v1'],
 'development_data_status':'Previously inspected synthetic development; not held out or blinded.',
 'no_fresh_generation':True,'fresh_963xxx_seeds_remain_unconsumed':True,
 'scientific_gates_unchanged':{'exposure_minimum':.99,'all_three_stopping_before_cap':True,'all_three_two_optimizer_agreement':True,'target_relative_change_abs_less_than':.01,'frequency_L1_less_than':.001,'segregating_relative_L1_less_than':.05,'all_physical_target_absolute_relative_error_maximum':.30,'original_six_primary_median_error_maximum':.20},
 'scientific_qualification':'No strict qualification claim; all original six and cap200 failures remain retained. Both development outcomes exported with all raw evidence and gates.',
 'pragmatic_release_rule':'Only root can authorize final inference after reviewing both complete development outcomes and the six original cohorts. New final wrapper requires a hash-bound explicit decision and retains all numerical gates in output; draft is not a submission.',
 'final_rule':'Fixed seed1 primary, no selection among seeds using truth or final outcomes. Any actual final numerical failures require root review before submission.',
 'stage_latest_start_utc':{'development':'2026-11-20T20:45:00Z','final':'2026-11-20T22:00:00Z'},
 'resources':{'development_jobs':2,'development_concurrency':2,'cpus_per_job':4,'development_minutes_per_job':55,'development_cpu_hour_cap':22/3,'root_final_minutes':55,'root_final_cpu_hour_cap':11/3,'total_cpu_hour_cap':11},
 'latest_final_end_utc':'2026-11-20T22:55:00Z',
 'launcher_sha256':h(Path(__file__))}
protocol_sha=put('task14_pragmatic_protocol_v1.json',plan)
s=r/'source_v12'; s.mkdir()
manifest=json.loads((r/'source_v11/source_manifest.json').read_text())
for name,expected in manifest.items():
 p=r/'source_v11'/name; assert h(p)==expected
 q=s/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);assert h(q)==expected
for name in ['lowcoverage_pragmatic.py','lowcoverage_pragmatic_guard.py','lowcoverage_assess_pragmatic.py','lowcoverage_predict_pragmatic.py']:
 q=s/'scripts'/name;shutil.copyfile(r/name,q);ast.parse(q.read_text());manifest['scripts/'+name]=h(q)
with (s/'source_manifest.json').open('x') as f:f.write(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
wrapper=(r/'develop_task14_extension_v3.sbatch').read_text().replace('source_v11','source_v12').replace('lowcoverage_deadline.py','lowcoverage_pragmatic.py').replace('extend-v3-development','pragmatic-v1-development').replace('ghist-lowcov-stabilize','ghist-lowcov-pragmatic')
with (r/'develop_task14_pragmatic_v1.sbatch').open('x') as f:f.write(wrapper)
sys.path[:0]=[str(s/'src'),str(s)]
g=importlib.import_module('scripts.lowcoverage_pragmatic_guard')
g.freeze(r,h(s/'source_manifest.json'),protocol_sha)
frozen_sha=h(r/'task14_pragmatic_freeze_v1.json')
clock_record=g.check_clock(r,'development')
job=subprocess.check_output(['sbatch','--parsable','--export=ALL,FROZEN_SHA='+frozen_sha,str(r/'develop_task14_pragmatic_v1.sbatch')],text=True).strip()
launch_sha=put('task14_pragmatic_development_launch_v1.json',{'job_id':job,'dispatched_at_utc':datetime.now(timezone.utc).isoformat(),'freeze_sha256':frozen_sha,'protocol_sha256':protocol_sha,'source_manifest_sha256':h(s/'source_manifest.json'),'wrapper_sha256':h(r/'develop_task14_pragmatic_v1.sbatch'),'dispatch_clock_guard':clock_record,'final_data_access':False,'fresh_data_generation':False})
print(json.dumps({'job':job,'freeze_sha256':frozen_sha,'protocol_sha256':protocol_sha,'manifest_sha256':h(s/'source_manifest.json'),'launch_sha256':launch_sha,'final_wrapper_sha256':h(s/'scripts/lowcoverage_predict_pragmatic.py')}))
