"""Separate Task 10 development experiment; never promotes a production release."""
from __future__ import annotations

import argparse
import csv
import gzip
import itertools
import json
import os
import re
import shutil
import subprocess
import sys
from concurrent.futures import ProcessPoolExecutor
from collections import defaultdict
from pathlib import Path

import numpy as np

from reconstruct_bonsai_pedigree import coverage_intervals, read_haplotype_segments, read_map
from fit_human_family_relationships import summarize_raw_lengths
from summarize_hapibd import genome_length
from validate_task10_complete_pipeline import (
    frozen_pair_predictions, score_predictions, save_json, sha256, map_bounds,
    parents_from_fam, family_truth,
)


def complete_features(segments: dict, samples: list[str], genome_cm: float) -> list[dict]:
    """All roster pairs including zero detected sharing, independent of scoring truth."""
    if len(set(samples)) != len(samples) or len(samples) < 2:
        raise ValueError("The genotype roster must contain unique sample identifiers")
    valid = set(itertools.combinations(sorted(samples), 2))
    if set(segments) - valid:
        raise ValueError("Segments reference a pair outside the genotype roster")
    return [dict(indID1=a, indID2=b, **summarize_raw_lengths(segments.get((a, b), []), genome_cm))
            for a, b in sorted(valid)]


def genotype_roster(path: Path) -> list[str]:
    opener = gzip.open if path.suffix == '.gz' else open
    with opener(path, 'rt') as handle:
        for line in handle:
            if line.startswith('#CHROM'):
                return line.rstrip().split('\t')[9:]
    raise ValueError('VCF has no sample header')


def detected_segments(path: Path, map_path: Path, representation: str) -> dict:
    grouped, _ = read_haplotype_segments(path)
    genetic_map = read_map(map_path)
    result = defaultdict(list)
    for (a, b, chrom), intervals in grouped.items():
        bp, cm = genetic_map[chrom]
        if representation == 'diploid_state':
            pieces = coverage_intervals(intervals)
        elif representation == 'raw_haplotype':
            pieces = [(start, end, False) for start, end, _, _ in intervals]
        else:
            raise ValueError('Unknown feature representation')
        for start, end, ibd2 in pieces:
            if start < bp[0] or end > bp[-1]:
                raise ValueError('Segment exceeds map bounds')
            values = np.interp([start, end], bp, cm)
            length = float(values[1] - values[0])
            if length > 0:
                result[(a, b)].append((chrom, length))
                if ibd2:
                    result[(a, b)].append((chrom, length))
    return result


def exact_segments(path: Path, identifiers: dict) -> dict:
    result = defaultdict(list)
    for line in path.read_text().splitlines():
        a, b, chrom, _, _, state, _, _, length = line.split()
        if a not in identifiers or b not in identifiers:
            continue
        pair = tuple(sorted((identifiers[a], identifiers[b])))
        result[pair].append((chrom, float(length)))
        if state == 'IBD2':
            result[pair].append((chrom, float(length)))
    return result


def write_features(rows: list[dict], path: Path) -> None:
    with path.open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def evaluate_representations(cohort: Path, assets: Path, output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=False)
    map_path = assets / 'external/ped-sim-map/refined_average.plink.map'
    identifiers = json.loads((cohort / 'identifiers.json').read_text())
    roster = genotype_roster(cohort / 'family.normalized.vcf.gz')
    truth = json.loads((cohort / 'truth.json').read_text())
    sources = {
        'exact_diploid_oracle': exact_segments(cohort / 'family.seg', identifiers),
        'raw_haplotype': detected_segments(cohort / 'detected.ibd.gz', map_path, 'raw_haplotype'),
        'diploid_state': detected_segments(cohort / 'detected.ibd.gz', map_path, 'diploid_state'),
    }
    candidate = assets / 'artifacts/task10_large_family/clean_spectrum_v1/model.joblib'
    baseline = assets / 'artifacts/task10_large_family/pair_model_min5/model.joblib'
    results = {}
    for name, segments in sources.items():
        rows = complete_features(segments, roster, genome_length(map_path))
        feature_path = output / f'{name}.csv'
        write_features(rows, feature_path)
        predictions = frozen_pair_predictions(feature_path, candidate, baseline, output / f'{name}.json')
        results[name] = score_predictions(truth, predictions)
    save_json(output / 'result.json', {'development_only': True, 'results': results,
        'cohort': str(cohort), 'input_hashes': {str(cohort / name): sha256(cohort / name)
        for name in ['identifiers.json', 'truth.json', 'family.seg', 'detected.ibd.gz']},
        'submission_ready': False, 'submission_count': 0})
    return results



TOPOLOGIES = {
    'cousins': {'depths': [2, 2, 3, 3, 4, 4, 5, 5], 'samples_per_branch': 2},
    'avuncular': {'depths': [1, 2, 3, 4], 'samples_per_branch': 2},
}


def pedigree_definition(topology: str) -> str:
    depths = TOPOLOGIES[topology]['depths']
    branches = len(depths)
    lines = [f'def validation 1 {max(depths) + 1}']
    for generation in range(2, max(depths) + 2):
        omitted = [str(i + 1) + 'n' for i, depth in enumerate(depths) if depth != generation - 1]
        lines.append(f"{generation} 2 {branches} " + ' '.join(omitted))
    return '\n'.join(lines) + '\n'


def simulated_founder_chromosome(job: tuple) -> dict:
    import msprime
    chrom, start, end, cm, seed, count, filename = job
    length = end - start + 1
    ancestry = msprime.sim_ancestry(samples=count, population_size=10000,
        sequence_length=length, recombination_rate=cm / (100 * length), random_seed=seed)
    mutated = msprime.sim_mutations(ancestry, rate=1.25e-8,
        model=msprime.BinaryMutationModel(), random_seed=seed + 1)
    retained, last = 0, -1000
    with gzip.open(filename, 'wt', compresslevel=1) as handle:
        for variant in mutated.variants():
            position = int(variant.site.position) + start
            minor = min(int(variant.genotypes.sum()), 2 * count - int(variant.genotypes.sum()))
            if position - last < 500 or minor / (2 * count) < 2 / 28:
                continue
            calls = '\t'.join(f'{a}|{b}' for a, b in np.asarray(variant.genotypes).reshape(count, 2))
            handle.write(f'{chrom}\t{position}\t.\tA\tC\t.\tPASS\t.\tGT\t{calls}\n')
            retained, last = retained + 1, position
    return {'chromosome': chrom, 'markers': retained, 'ancestry_seed': seed,
            'mutation_seed': seed + 1}


def generate_founders(bounds: dict, seed: int, count: int, root: Path, workers: int) -> Path:
    root.mkdir()
    jobs = [(chrom, *bounds[chrom], seed + 100 * int(chrom), count,
             str(root / f'chr{chrom}.vcf.gz')) for chrom in sorted(bounds, key=int)]
    with ProcessPoolExecutor(max_workers=workers) as pool:
        records = list(pool.map(simulated_founder_chromosome, jobs))
    output = root / 'founders.vcf.gz'
    with gzip.open(output, 'wt', compresslevel=1) as writer:
        writer.write('##fileformat=VCFv4.2\n')
        writer.write('##FORMAT=<ID=GT,Number=1,Type=String,Description="Genotype">\n')
        for chrom in sorted(bounds, key=int):
            writer.write(f'##contig=<ID={chrom},length={bounds[chrom][1] + 1}>\n')
        writer.write('#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\t')
        writer.write('\t'.join(f'founder_{i}' for i in range(count)) + '\n')
        for job in jobs:
            with gzip.open(job[-1], 'rt') as reader:
                shutil.copyfileobj(reader, writer)
    save_json(root / 'generation.json', {'founders': count, 'chromosomes': records})
    return output


def select_vcf(source: Path, destination: Path, topology: str, parents: dict) -> dict:
    depths = TOPOLOGIES[topology]['depths']
    identifiers = {}
    indices = []
    variants = 0
    with gzip.open(source, 'rt') as reader, gzip.open(destination, 'wt', compresslevel=1) as writer:
        for line in reader:
            if line.startswith('#CHROM'):
                fields = line.rstrip().split('\t')
                for i, sample in enumerate(fields[9:]):
                    match = re.fullmatch(r'validation1_g(\d+)-b(\d+)-i([12])', sample)
                    if match and len(parents[sample]) == 2:
                        generation, branch, _ = map(int, match.groups())
                        if generation - 1 == depths[branch - 1]:
                            identifiers[sample] = f'sample_{len(identifiers)}'
                            indices.append(i + 9)
                writer.write('\t'.join(fields[:9] + list(identifiers.values())) + '\n')
            elif line.startswith('#'):
                writer.write(line)
            else:
                fields = line.rstrip().split('\t')
                calls = [fields[i] for i in indices]
                if any(call.split(':')[0] not in {'0|0', '0|1', '1|0', '1|1'} for call in calls):
                    raise ValueError('Phased, complete synthetic genotype contract failed')
                writer.write('\t'.join(fields[:9] + calls) + '\n')
                variants += 1
    if len(identifiers) != 2 * len(depths) or not variants:
        raise ValueError(f'Unexpected genotype roster: {identifiers}')
    return identifiers


def file_hashes(root: Path) -> dict:
    return {str(path.resolve()): sha256(path) for folder in ['scripts', 'src']
            for path in sorted((root / folder).rglob('*.py'))}


def verify_inputs(hashes: dict) -> None:
    for path, expected in hashes.items():
        if sha256(Path(path)) != expected:
            raise RuntimeError(f'Immutable input changed: {path}')


def run_confirmation(args) -> None:
    root, assets, output = args.project_root.resolve(), args.asset_root.resolve(), args.out_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    protocol = json.loads(args.protocol.read_text())
    item = next((row for row in protocol['cohorts'] if row['index'] == args.index), None)
    if item is None:
        raise ValueError('Cohort must be in the preregistered protocol')
    if protocol['candidate'] != 'frozen-classifier-diploid-state-whole-family-v1':
        raise ValueError('Unrecognized candidate')
    topology, seed = item['topology'], item['seed']
    env = {**os.environ, 'PYTHONPATH': f'{root / "src"}:{root / "scripts"}',
           'PYTHONDONTWRITEBYTECODE': '1'}
    commands = []
    def command(name, words):
        with (output / f'{name}.log').open('w') as log:
            result = subprocess.run(list(map(str, words)), cwd=root, env=env,
                stdout=log, stderr=subprocess.STDOUT)
        commands.append({'stage': name, 'command': list(map(str, words)), 'exit_code': result.returncode})
        save_json(output / 'commands.json', commands)
        print(name, result.returncode, flush=True)
        if result.returncode:
            raise RuntimeError(f'{name} failed')
    def script(name):
        return [sys.executable, root / 'scripts' / name]
    map_path = assets / 'external/ped-sim-map/refined_average.plink.map'
    simmap = assets / 'external/ped-sim-map/refined_mf.simmap'
    pedsim = assets / 'external/ped-sim/ped-sim'
    interference = assets / 'external/ped-sim/interfere/nu_p_campbell.tsv'
    detector = assets / 'external/hap-ibd/hap-ibd.jar'
    candidate = assets / 'artifacts/task10_large_family/clean_spectrum_v1/model.joblib'
    baseline = assets / 'artifacts/task10_large_family/pair_model_min5/model.joblib'
    hashes = file_hashes(root)
    hashes.update({str(path): sha256(path) for path in
        [map_path, simmap, pedsim, interference, detector, candidate, baseline, args.protocol.resolve()]})
    save_json(output / 'preregistered_design.json', {'item': item, 'protocol': protocol,
        'hashes': hashes, 'submission_count': 0, 'scientific_release_qualified': False})
    depths = TOPOLOGIES[topology]['depths']
    founder_count = 2 + len(depths) * (max(depths) - 1)
    founders = generate_founders(map_bounds(map_path), seed, founder_count, output / 'founders', args.workers)
    definition = output / 'family.def'
    definition.write_text(pedigree_definition(topology))
    command('pedsim', [pedsim, '-d', definition, '-m', simmap, '-i', founders,
        '-o', output / 'family', '--intf', interference, '--seed', seed + 9000,
        '--fam', '--keep_phase', '--err_rate', 0, '--miss_rate', 0])
    parents = parents_from_fam(output / 'family-everyone.fam')
    normalized = output / 'family.normalized.vcf.gz'
    identifiers = select_vcf(output / 'family.vcf.gz', normalized, topology, parents)
    save_json(output / 'identifiers.json', identifiers)
    truth = family_truth(parents, identifiers)
    save_json(output / 'truth.json', truth)
    hashes.update({str(output / name): sha256(output / name) for name in
                   ['truth.json', 'identifiers.json', 'family.normalized.vcf.gz', 'family-everyone.fam']})
    save_json(output / 'inference_input_hashes.json', hashes)
    prepared = output / 'prepared.vcf.gz'
    command('prepare', script('prepare_hapibd_vcf.py') + ['--input', normalized, '--output', prepared])
    command('detector', ['java', '-Xmx14g', '-jar', detector, f'gt={prepared}', f'map={map_path}',
        f'out={output / "detected"}', 'min-seed=1.0', 'min-extend=0.2', 'min-output=2.0',
        'min-markers=100', 'max-gap=1000', f'nthreads={args.workers}'])
    results = evaluate_representations(output, assets, output / 'representation_comparison')
    clusters = output / 'clusters.json'
    save_json(clusters, {'families': [sorted(identifiers.values())], 'samples': len(identifiers),
                         'family_sizes': [len(identifiers)], 'source': 'Task10 single-family contract'})
    for name, degree, types in [('fast', 5, 2), ('medium', 5, 3)]:
        command(name, script('reconstruct_human_branch_pedigrees.py') + ['--ibd', output / 'detected.ibd.gz',
            '--map', map_path, '--clusters', clusters, '--threshold-cm', 10,
            '--max-add-degree', degree, '--max-rel-types', types, '--out', output / f'{name}.json'])
    command('consensus', script('consensus_human_family_pedigree.py') + ['--pair-predictions',
        output / 'representation_comparison/diploid_state.json', '--bonsai', output / 'fast.json',
        output / 'medium.json', '--topology-boost', 1, '--require-flat-degree-agreement',
        '--out-dir', output / 'consensus'])
    with (output / 'consensus/candidate.csv').open() as handle:
        predictions = list(csv.DictReader(handle))
    scores = score_predictions(truth, predictions)
    verify_inputs(hashes)
    cohort = {'cohort_id': f'{topology}_{seed}', 'truth': truth, 'predictions': predictions}
    save_json(output / 'scoring_cohort.json', cohort)
    retained = {str(path.relative_to(output)): sha256(path) for path in output.rglob('*')
        if path.is_file() and path.name not in {'result.json'}}
    save_json(output / 'result.json', {'state': 'COMPLETED', 'item': item, 'candidate': scores,
        'comparisons': results, 'outputs': retained,
        'protocol_sha256': sha256(args.protocol), 'submission_ready': False, 'submission_count': 0})
    print(json.dumps({'candidate': scores, 'comparisons': results}), flush=True)



def run_whole_family(args) -> None:
    root, assets, cohort, output = args.project_root.resolve(), args.asset_root.resolve(), args.cohort.resolve(), args.out_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    roster = genotype_roster(cohort / 'family.normalized.vcf.gz')
    map_path = assets / 'external/ped-sim-map/refined_average.plink.map'
    truth = json.loads((cohort / 'truth.json').read_text())
    features = output / 'features.csv'
    write_features(complete_features(detected_segments(cohort / 'detected.ibd.gz', map_path,
        'diploid_state'), roster, genome_length(map_path)), features)
    predicted = frozen_pair_predictions(features,
        assets / 'artifacts/task10_large_family/clean_spectrum_v1/model.joblib',
        assets / 'artifacts/task10_large_family/pair_model_min5/model.joblib', output / 'pair_predictions.json')
    clusters = output / 'clusters.json'
    save_json(clusters, {'families': [sorted(roster)], 'samples': len(roster),
        'family_sizes': [len(roster)], 'source': 'Task10 single-family contract'})
    env = {**os.environ, 'PYTHONPATH': f'{root / "src"}:{root / "scripts"}', 'PYTHONDONTWRITEBYTECODE': '1'}
    hashes = file_hashes(root)
    hashes.update({str(cohort / name): sha256(cohort / name) for name in
        ['truth.json', 'detected.ibd.gz', 'family.normalized.vcf.gz']})
    save_json(output / 'protocol.json', {'design': 'whole-family development diagnosis',
        'settings': [[5, 2], [5, 3]], 'hashes': hashes, 'submission_ready': False})
    for name, degree, types in [('fast', 5, 2), ('medium', 5, 3)]:
        with (output / f'{name}.log').open('w') as log:
            subprocess.run([sys.executable, root / 'scripts/reconstruct_human_branch_pedigrees.py',
                '--ibd', cohort / 'detected.ibd.gz', '--map', map_path, '--clusters', clusters,
                '--threshold-cm', '10', '--max-add-degree', str(degree), '--max-rel-types', str(types),
                '--out', output / f'{name}.json'], check=True, env=env, stdout=log, stderr=subprocess.STDOUT)
    with (output / 'consensus.log').open('w') as log:
        subprocess.run([sys.executable, root / 'scripts/consensus_human_family_pedigree.py',
            '--pair-predictions', output / 'pair_predictions.json', '--bonsai', output / 'fast.json',
            output / 'medium.json', '--topology-boost', '1', '--require-flat-degree-agreement',
            '--out-dir', output / 'consensus'], check=True, env=env, stdout=log, stderr=subprocess.STDOUT)
    with (output / 'consensus/candidate.csv').open() as handle:
        predictions = list(csv.DictReader(handle))
    verify_inputs(hashes)
    save_json(output / 'result.json', {'state': 'COMPLETED', 'pair': score_predictions(truth, predicted),
        'consensus': score_predictions(truth, predictions), 'submission_ready': False})


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['diagnose', 'whole-family', 'cohort'])
    parser.add_argument('--cohort', type=Path)
    parser.add_argument('--asset-root', type=Path, required=True)
    parser.add_argument('--out-dir', type=Path, required=True)
    parser.add_argument('--project-root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--protocol', type=Path)
    parser.add_argument('--index', type=int)
    parser.add_argument('--workers', type=int, default=4)
    args = parser.parse_args()
    if not os.environ.get('SLURM_JOB_ID'):
        parser.error('Execute model and full-genome work in scheduled Slurm jobs')
    if args.command == 'diagnose':
        print(json.dumps(evaluate_representations(args.cohort, args.asset_root, args.out_dir), indent=2))
    elif args.command == 'whole-family':
        run_whole_family(args)
    else:
        if args.protocol is None or args.index is None:
            parser.error('Confirmation requires a preregistered protocol and cohort index')
        run_confirmation(args)


if __name__ == '__main__':
    main()
